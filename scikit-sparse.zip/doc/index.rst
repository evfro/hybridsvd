.. scikit-sparse documentation master file, created by
   sphinx-quickstart on Sat Dec 12 22:10:41 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

scikit-sparse - Sparse matrix extensions for SciPy
==================================================

Contents:

.. toctree::
   :maxdepth: 2

   overview.rst

   cholmod.rst

   changes.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

