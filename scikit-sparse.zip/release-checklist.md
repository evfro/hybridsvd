1) update doc/changes.rst
2) make sure docs are up to date
3) tag
4)
```
    ./release-checklist.sh
```
5) announce release on:
        web page
        mailing list
        scipy-dev?
        pypi
